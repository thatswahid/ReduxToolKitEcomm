import React from 'react'
import './Overview.css'
import SwiftImgSlider from './SwiftImgSlider'


function Overview() {

 

        function ShowSlider() {
        document.getElementById("ImgHide").style.display = "block"
        // document.getElementById("showMainBody_14422").style.display = "none"
        document.getElementById("yujikThemeBosy").style.display = "none"
        document.getElementById("yujikThemeBosy2").style.display = "none"
        
    }

    function imgNone() {
        document.getElementById("ImgHide").style.display = "none"
        document.getElementById("yujikThemeBosy").style.display = "block"
        document.getElementById("yujikThemeBosy2").style.display = "block"

    }


    return (
        <>
            
            <div className="Overview">
                <div className='TopSecImg_26522'>
                    <img src="https://tripfinder-redq.firebaseapp.com/static/media/single-post-bg.fe05ed7c.jpg" alt="" style={{ width: "100%" }} />
                    <div className="btnbtn_26522">
                        <button onClick={ShowSlider}>View Photos</button>
                       
                    </div>
                </div>
            </div>

            <div className="tabSec_26522 mb-5" >
                <ul>
                    <li><a href="#overview" >Overview</a></li>
                    <li><a href="#amenities"> Amenities</a></li>
                    <li><a href="#location">  Location</a></li>
                </ul>
            </div>



            <div className='container'>

                <div className="row">
                    <div className="col-md-8">
                        <div className="bottomSec_26522 ">
                            <div>
                                <h6>Broklyn New York, United States Of America</h6>
                                <h3>Awesome Cotton Chicken</h3>
                                {
                                    Array(5).fill().map((i) => (
                                        <span>⭐</span>
                                    ))
                                } <span>Awesome (35)</span>
                                <p className='mt-4'>In South Williamsburg only a few blocks inland from the East River, Marlo &Sons is a rustic respite with nice wine, good cocktails, and excellent snacking fare such as oysters, local cheese, and potato tortilla. But thereâ€™s more: seasonal salads and soups, the famous brick chicken, a dimly lit space outfitted in various types of wood(this is an Andrew Tarlow restaurant, after all). In many ways.</p>
                                <a href="">Read More About The Hotel</a>
                            </div>
                        </div>
                        <hr />



                        <div className='Amenities_26522'>
                            <h3>Amenities</h3>

                            <div className="row justify-content-center text-center mb-3" >
                                <div className="col-md-3">
                                    <div className='card_26522'>
                                        <i class="fa-solid fa-wifi"></i><br />
                                        <span>Free wifi</span>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className='card_26522'>
                                        <i class="fa-solid fa-car"></i><br />
                                        <span>Free Parking</span>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className='card_26522'>
                                        <i class="fa-solid fa-person-swimming"></i><br />
                                        <span>Free Pool</span>
                                    </div>
                                </div>
                                <div className="col-md-3">
                                    <div className='card_26522'>
                                        <i class="fa-solid fa-tree"></i><br />
                                        <span>Air Freshener</span>
                                    </div>
                                </div>
                            </div>
                            <a href="">Show All Amenities</a>
                        </div>
                        <hr />


                        <div className="Location_26522">
                            <h3>Location</h3>
                            <p>Take an easy walk to the main historic sites of the city. The neighborhood is perfect for an authentic taste of Roman life, with shops, art galleries, restaurants, bars, and clubs all nearby and ready to be discovered.</p>
                            <h6 style={{marginBottom:"0px"}}>Distance from Leonardo da Vinci International Airport</h6>
                            <p>26 mins by car without traffic</p>
                            <div>
                                <iframe className='iframe_26522' src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3502.3323562934124!2d77.35896621440689!3d28.619799491409406!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390ce59e57342a11%3A0xbe4a479f9d401aa4!2sNoida%20One%20Cyber%20Park!5e0!3m2!1sen!2sin!4v1653559302289!5m2!1sen!2sin"  allowFullScreen loading="lazy" referrerPolicy="no-referrer-when-downgrade" />

                            </div>
                        </div>
                    </div>
                    <div className="col-md-4">
                        <div className="tripYujik">
                            <h6> <b>$162</b> / night</h6>
                            <hr />
                            <p>Date</p>
                            <span><input type="date" className='form-control mb-2' name="dob" data-placeholder="Check In" required aria-required="true" /></span>
                            <span>
                                <input type="date" name="dob" className='form-control mb-3' data-placeholder="Check Out" required aria-required="true" />
                            </span>
                            <p>Guest</p>
                            <input type="text" className='form-control mb-2' placeholder='Room' />
                            <input type="text" className='form-control mb-3' placeholder='Guest' />
                            <button className="w-100 BtnBtn1_26522">Book Hotel</button>
                            <hr />
                        </div>

                        {/* ===== */}


                    </div>
                </div>

                    {/* ===== */}
                
           
            </div>
            <div id="ImgHide" style={{ display: "none", background: "black" , width:"100%"}}>
                <SwiftImgSlider />
                <div> <span onClick={imgNone} style={{ position: "absolute", top: "5px", color: "white", right: "20px", fontSize: "25px", cursor: "pointer", zIndex: "1222" }}>X</span></div>
            </div>
         


        </>
    )
}

export default Overview