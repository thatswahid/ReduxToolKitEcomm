import React,{useState} from 'react'
import ListTripPage from './ListTripPage'
import './Contact.css'
import Fav from './Fav'

function Contact() {

    const [first, setfirst] = useState(true)
    const [second, setsecond] = useState(false)
    const [third, setthird] = useState(false)

    function list() {
        setfirst(true)
        setsecond(false)
        setthird(false)
    }
    function favourite() {
        setfirst(false) 
        setsecond(false)
        setthird(true)

    }
    function contact() {
        setfirst(false) 
        setsecond(true)
        setthird(false)

    }

    return (
        <>
           

            <div className='tab_25522'>
                <ul>
                    <li className={`${first?"active_876":""}`} onClick={list }><a href="#List">Listing</a></li>
                    <li className={`${third?"active_876":""}`} onClick={favourite}><a href="#Favourite">Favourite</a></li>
                    <li className={`${second?"active_876":""}`} onClick={contact}><a  href="#Contact">Contact</a></li>
                </ul>
            </div>


            {
                first ? (
                    <div className='mt-4' >
                       <ListTripPage/>
                    </div>
                ) :''
                
                
                
               
            }

            {
             third ?(
                    <div className='mt-4'>
                    <Fav/>
                </div>     
                ):''
            }


           

           
            {
                second ? (
                    <div className="container mt-5">
                        <div className="row">
                            <div className="col-md-8">

                                <div className="body_25522">
                                    <div>
                                        <h3 className="fcf-h3">Send Message</h3>
                                        <form className="fcf-form-class">
                                            <div className="group_25522">
                                                <label htmlFor="Name" className="label_25522">Your number</label>
                                                <div className="input_group_25522">
                                                    <input type="text" name="Name" className="control_25522" required />
                                                </div>
                                            </div>
                                            <div className="group_25522">
                                                <label htmlFor="Email" className="label_25522">Your email address</label>
                                                <div className="input_group_25522">
                                                    <input type="email" name="Email" className="control_25522" required />
                                                </div>
                                            </div>
                                            <div className="group_25522">
                                                <label htmlFor="Message" className="label_25522">Your message</label>
                                                <div className="input_group_25522">
                                                    <textarea name="Message" className="control_25522" rows={6} maxLength={3000} required defaultValue={""} />
                                                </div>
                                            </div>
                                            <div className="group_25522">
                                                <button type="submit" className="btn_25522 btn_primary_25522 btn_group_25522 btn_block_25522">Send Message</button>
                                            </div>
                                        </form>
                                    </div>
                                </div>

                            </div>
                            <div className="col-md-4">
                                <div className='rightside_25522'>
                                    <div className='mb-4'>
                                        <span><b>Phone</b></span><br />
                                        <span>825-362-3175</span>
                                    </div>
                                    <div className='mb-4'>
                                        <span><b>Email</b></span><br />
                                        <span>Elliot.Hagenes35@gmail.com</span>
                                    </div>
                                    <div className='mb-4'>
                                        <span><b>Address</b></span><br />
                                        <span>Noida Sec-62, Noida One</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>  
                ):''
}
            {/* form section================= */}
           
        </>
    )
}

export default Contact