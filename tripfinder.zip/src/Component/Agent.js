import React from 'react'
import AgetPage from './AgetPage'
import Contact from './Contact'
function Agent() {
  return (
    <>
            <AgetPage/>
            <Contact/>
    </>
  )
}

export default Agent