import React from 'react'
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import './Destinations.css'
import {Link} from 'react-router-dom'
function Destinations() {
    const responsive = {
        superLargeDesktop: {
            // the naming can be any, depends on you.
            breakpoint: { max: 4000, min: 3000 },
            items: 5
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 5
        },
        tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 2
        },
        mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1
        }
    };
    return (
        <>

            <div className=" mt-5 ">
                <div className='explore mb-3'>
                <span style={{marginLeft:'20px' , fontSize:'25px',fontWeight:'500'}}> <b>Explore Destinations</b></span>
                <span style={{float:'right', marginRight:'20px', fontSize:'20px'}} className='mt-2 viewAll'> <Link to="/list">View All</Link> </span>
                </div>
                
               
                <Carousel responsive={responsive} infinite={true} className="car_28522">
                <Link to="/list" className='listing'>
                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/london.jpg" alt="" />
                        <div className='texthh'><h6>London</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>

                    <Link to="/list" className='listing'>
                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/newyork.jpg" alt="" />
                        <div className='texthh'><h6>Paris</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>
                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/barcelona.jpg" alt="" />
                        <div className='texthh'><h6>Rome</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>
                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/rome.jpg" alt="" />
                        <div className='texthh'><h6>New York</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/london.jpg" alt="" />
                        <div className='texthh'><h6>Barcelona</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>
                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/newyork.jpg" alt="" />
                        <div className='texthh'><h6>Cairo</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>
                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/barcelona.jpg" alt="" />
                        <div className='texthh'><h6>Abu Dhabi</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/rome.jpg" alt="" />
                        <div className='texthh'><h6>Las Vegas</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/london.jpg" alt="" />
                        <div className='texthh'><h6>Sydney</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/newyork.jpg" alt="" />
                        <div className='texthh'><h6>Prague</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/barcelona.jpg" alt="" />
                        <div className='texthh'><h6>London</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/rome.jpg" alt="" />
                        <div className='texthh'><h6>London</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/london.jpg" alt="" />
                        <div className='texthh'><h6>London</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/newyork.jpg" alt="" />
                        <div className='texthh'><h6>London</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/barcelona.jpg" alt="" />
                        <div className='texthh'><h6>London</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                    <Link to="/list" className='listing'>

                    <div className="carousel_img">
                        <img src="http://s3.amazonaws.com/redqteam.com/tripfinder-images/rome.jpg" alt="" />
                        <div className='texthh'><h6>London</h6></div>
                        <div className="pera_24522">786 Hotels</div>
                        <div className="overlay_24522"></div>
                    </div>
                    </Link>
                </Carousel>
                
            </div>
        </>
    )
}

export default Destinations