import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Agent from "./Agent";
import Home from "./Home";
import LIsting from "./LIsting";
import Navbar from "./Navbar";
import Pricing from "./Pricing";
import SignIn from "./SignIn";
import SignUp from "./SignUp";
import Overview from './Overview'

function Routing() {
  return (
    <>
      <BrowserRouter>
        <Navbar/>
        <Routes>
          <Route path="/" element={<Home/>} />
          <Route path="list" element={<LIsting/>} />
          <Route path="agent" element={<Agent/>} />
          <Route path="price" element={<Pricing/>} />
          <Route path="signin" element={<SignIn/>} />
          <Route path="signup" element={<SignUp/>} />
          <Route path="overview" element={<Overview/>} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default Routing;
