import React from 'react'

import ChoiceTopHotel from './ChoiceTopHotel';
function Fav() {
    
  return (
    <>
    <ChoiceTopHotel/>
    </>
  )
}

export default Fav