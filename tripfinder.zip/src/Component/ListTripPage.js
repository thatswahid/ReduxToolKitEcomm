import React from 'react'
import ChoiceTopHotel from './ChoiceTopHotel'
function ListTripPage() {

  return (
    <>
      <ChoiceTopHotel/>
      <ChoiceTopHotel/>
    </>
  )
}

export default ListTripPage