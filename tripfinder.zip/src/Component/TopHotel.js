import React from 'react'
import { Link } from 'react-router-dom'
import './TopHotel.css'
import ChoiceTopHotel from './ChoiceTopHotel'

function TopHotel() {
  return (
    <>
             <div className='explore mb-1 mt-4'>
                <span style={{marginLeft:'20px' , fontSize:'25px',fontWeight:'500'}}> <b className='choiceHotel'>Travelers’ Choice: Top hotels</b></span>
                <span style={{float:'right', marginRight:'20px', fontSize:'20px'}} className='mt-2 viewAll'> <Link to="/list">View All</Link> </span>
            </div>
      <div>
        <div className='Travelers_28522'>
            <ChoiceTopHotel/>
            <ChoiceTopHotel/>
        </div>
      </div>
    </>
  )
}

export default TopHotel