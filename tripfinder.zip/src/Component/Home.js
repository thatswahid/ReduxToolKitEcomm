import React from 'react'
import ImageSliders from './ImageSlider'
function Home() {
  return (
    <div>
      <ImageSliders/>
     
    </div>
  )
}

export default Home