import React from 'react'

import ChoiceTopHotel from './ChoiceTopHotel'
function LIsting() {



  return (
    <>
      <div className="btnList container mt-3">
        <button>Amenities</button>
        <button>Property Type</button>
        <button>Choose Date</button>
        <button>Price per Night</button>
        <button>Room Guest</button>
        <button>Reset</button>
      </div>

      <div className='chooseHotel_28522'>
        <ChoiceTopHotel />
        <ChoiceTopHotel />
        <ChoiceTopHotel />
      </div>
    </>
  )
}

export default LIsting