import React,{useState} from 'react'
import './PriceCss.css'

function Priceing() {

 const [togglefirst, settogglefirst] = useState(true)
    function firstbtn() {
        settogglefirst(true)
    }

    function secondbtn() {
        settogglefirst(false)
    }
    return (
        <>
            
            <div className="">
                <div className='TopSec_24522'>
                    <h1 >Select Your Pricing Plan</h1>
                    <p>Simple Transparent pricing for everyone, whether you are local hotel owner or an agent.</p>
                    <button onClick={firstbtn} className='btnbtn_24522'>Monthly</button>  <button onClick={secondbtn} className='btnbtn_24522'>Annually</button>
                </div>
                {
                    togglefirst ? (
                        <section className="pricing_24522 py-5">
                            <div className="container">
                                <div className="row">
                                   
                                    <div className="col-lg-4">
                                        <div className="card mb-5 mb-lg-0">
                                            <div className="card-body">
                                                <h5 className="card_title_24522 text-muted text-uppercase text-center">Basic Plan</h5>
                                                <h6 className="card_price_24522 text-center">$0.00 USD<span className="period_24522">/month</span></h6>
                                                <hr />
                                                <ul className="fa-ul">
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Ultimate campaigns</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Basic donner data</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Team fundraising</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Community Access</li>
                                                    <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Unlimited
                                                        Private Projects</li>
                                                    <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Dedicated
                                                        Phone Support</li>
                                                    <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Basic theming
                                                    </li>
                                                    <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Monthly Status
                                                        Reports</li>
                                                </ul>
                                                <div className="d-grid">
                                                    <a href="#" className="btn btn-primary text-uppercase">Select Plan</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                   
                                    <div className="col-lg-4">
                                        <div className="card mb-5 mb-lg-0">
                                            <div className="card-body">
                                                <h5 className="card_title_24522 text-muted text-uppercase text-center">Standard Plan</h5>
                                                <h6 className="card_price_24522 text-center">$9<span className="period_24522">/month</span></h6>
                                                <hr />
                                                <ul className="fa-ul">
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>5 Users</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Basic donner data</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Team fundraising</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Community Access</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Multi tasking</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Basic registration & Ticketing</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Basic theming</li>
                                                    <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Monthly Status
                                                        Reports</li>
                                                </ul>
                                                <div className="d-grid">
                                                    <a href="#" className="btn btn-primary text-uppercase">Select Plan</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    
                                    <div className="col-lg-4">
                                        <div className="card">
                                            <div className="card-body">
                                                <h5 className="card_title_24522 text-muted text-uppercase text-center">Premium Plan</h5>
                                                <h6 className="card_price_24522 text-center">$49<span className="period_24522">/month</span></h6>
                                                <hr />
                                                <ul className="fa-ul">
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Unlimited Users
                                                    </li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Basic donner data</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Team fundraising</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Community Access</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Multi tasking</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Basic registration & Ticketing</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Unlimited Free
                                                        Subdomains</li>
                                                    <li><span className="fa-li"><i className="fas fa-check" /></span>Monthly Status Reports</li>
                                                </ul>
                                                <div className="d-grid">
                                                    <a href="#" className="btn btn-primary text-uppercase">Select Plan</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </section>
                    ) : (
                            <section className="pricing_24522 py-5">
                                <div className="container">
                                    <div className="row">
                                        
                                        <div className="col-lg-4">
                                            <div className="card mb-5 mb-lg-0">
                                                <div className="card-body">
                                                    <h5 className="card_title_24522 text-muted text-uppercase text-center">BASIC Plan</h5>
                                                    <h6 className="card_price_24522 text-center">$0.786 USD<span className="period_24522">/Year</span></h6>
                                                    <hr />
                                                    <ul className="fa-ul">
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Ultimate campaigns</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Basic donner data</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Team fundraising</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Community Access</li>
                                                        <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Unlimited
                                                            Private Projects</li>
                                                        <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Dedicated
                                                            Phone Support</li>
                                                        <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Basic theming
                                                        </li>
                                                        <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Monthly Status
                                                            Reports</li>
                                                    </ul>
                                                    <div className="d-grid">
                                                        <a href="#" className="btn btn-primary text-uppercase">Select Plan</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="col-lg-4">
                                            <div className="card mb-5 mb-lg-0">
                                                <div className="card-body">
                                                    <h5 className="card_title_24522 text-muted text-uppercase text-center">Standard Plan</h5>
                                                    <h6 className="card_price_24522 text-center">$786<span className="period_24522">/Year</span></h6>
                                                    <hr />
                                                    <ul className="fa-ul">
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>5 Users</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Basic donner data</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Team fundraising</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Community Access</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Multi tasking</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Basic registration & Ticketing</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Basic theming</li>
                                                        <li className="text-muted"><span className="fa-li"><i className="fas fa-times" /></span>Monthly Status
                                                            Reports</li>
                                                    </ul>
                                                    <div className="d-grid">
                                                        <a href="#" className="btn btn-primary text-uppercase">Select Plan</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                        
                                        <div className="col-lg-4">
                                            <div className="card">
                                                <div className="card-body">
                                                    <h5 className="card_title_24522 text-muted text-uppercase text-center">Premium Plan</h5>
                                                    <h6 className="card_price_24522 text-center">$786<span className="period_24522">/Year</span></h6>
                                                    <hr />
                                                    <ul className="fa-ul">
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Unlimited Users
                                                        </li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Basic donner data</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Team fundraising</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Community Access</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Multi tasking</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Basic registration & Ticketing</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Unlimited Free
                                                            Subdomains</li>
                                                        <li><span className="fa-li"><i className="fas fa-check" /></span>Monthly Status Reports</li>
                                                    </ul>
                                                    <div className="d-grid">
                                                        <a href="#" className="btn btn-primary text-uppercase">Select Plan</a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </section>
                    )
                }
                
            
                   
                      
                

            </div>
        </>
    )
}

export default Priceing