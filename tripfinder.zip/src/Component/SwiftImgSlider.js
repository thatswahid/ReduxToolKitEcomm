import React from 'react'
import './Overview.css'
import SwiftSlider from 'react-swift-slider'

function SwiftImgSlider() {
    const data = [
        { 'id': '1', 'src': 'https://cdn.pixabay.com/photo/2016/07/30/00/03/winding-road-1556177_960_720.jpg' },
        { 'id': '2', 'src': 'https://cdn.pixabay.com/photo/2017/08/06/18/29/woman-2594934_960_720.jpg' },
        { 'id': '3', 'src': 'https://cdn.pixabay.com/photo/2018/11/29/21/19/hamburg-3846525_960_720.jpg' },
        { 'id': '4', 'src': 'https://cdn.pixabay.com/photo/2018/09/04/16/48/taj-mahal-3654227_960_720.jpg' },
        { 'id': '5', 'src': 'https://cdn.pixabay.com/photo/2020/06/06/18/34/couple-5267726_960_720.jpg' }
    ];
  return (
      <>
      <div className='container imgSlider_14422'>
                <SwiftSlider data={data} height={580} />
            </div>
      </>
  )
}

export default SwiftImgSlider