import React from 'react'
import Carousel from 'react-multi-carousel';
import 'react-multi-carousel/lib/styles.css';
import {Link} from 'react-router-dom'
import './LIst.css'
function ChoiceTopHotel() {
    const responsive = {
        superLargeDesktop: {
            // the naming can be any, depends on you.
            breakpoint: { max: 4000, min: 3000 },
            items: 5
        },
        desktop: {
            breakpoint: { max: 3000, min: 1024 },
            items: 1
        },
        tablet: {
            breakpoint: { max: 1024, min: 464 },
            items: 2
        },
        mobile: {
            breakpoint: { max: 464, min: 0 },
            items: 1
        }
    };
  return (
    <>
  <div className="row" style={{padding:'10px 15px' , margin:'0'}}>
         <div className="col-md-2" style={{padding:'3px'}} >
            
      <Carousel responsive={responsive} infinite={true} swipeable={false} >
                
                   
                 
                    <div className="carousel_img">
                        <img src="https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                        <div className="listStar">
                          <para>52623 Donnie Roads</para>
                          <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                          <span>$223.00/Night - Free Cancellation</span>
                          <h6>⭐⭐⭐⭐⭐</h6>
                        </div>
                    </div>

                    <div className="carousel_img">
                        <img src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" />
                        <div className="listStar">
                          <para>52623 Donnie Roads</para>
                          <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                          <span>$223.00/Night - Free Cancellation</span>
                          <h6>⭐⭐⭐⭐⭐</h6>
                        </div>
                    </div>
                 
                    <div className="carousel_img">
                        <img src="https://images.pexels.com/photos/2062431/pexels-photo-2062431.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                        <div className="listStar">
                          <para>52623 Donnie Roads</para>
                          <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                          <span>$223.00/Night - Free Cancellation</span>
                          <h6>⭐⭐⭐⭐⭐</h6>
                        </div>
                    </div>
                    </Carousel>
      </div>
  
      <div className="col-md-2" style={{padding:'3px'}} >
            
      <Carousel responsive={responsive} infinite={true} swipeable={false} >
                
               
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>

                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/2062431/pexels-photo-2062431.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
                </Carousel>
      </div>
  
      <div className="col-md-2" style={{padding:'3px'}}>
            
      <Carousel responsive={responsive} infinite={true} swipeable={false} >
                
                    
                 
                    <div className="carousel_img">
                        <img src="https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                        <div className="listStar">
                          <para>52623 Donnie Roads</para>
                          <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                          <span>$223.00/Night - Free Cancellation</span>
                          <h6>⭐⭐⭐⭐⭐</h6>
                        </div>
                    </div>

                    <div className="carousel_img">
                        <img src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" />
                        <div className="listStar">
                          <para>52623 Donnie Roads</para>
                          <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                          <span>$223.00/Night - Free Cancellation</span>
                          <h6>⭐⭐⭐⭐⭐</h6>
                        </div>
                    </div>
                 
                    <div className="carousel_img">
                        <img src="https://images.pexels.com/photos/2062431/pexels-photo-2062431.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                        <div className="listStar">
                          <para>52623 Donnie Roads</para>
                          <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                          <span>$223.00/Night - Free Cancellation</span>
                          <h6>⭐⭐⭐⭐⭐</h6>
                        </div>
                    </div>
                    </Carousel>
      </div>
  
      <div className="col-md-2" style={{padding:'3px'}}>
            
      <Carousel responsive={responsive} infinite={true} swipeable={false} >
                
               
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>

                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/2062431/pexels-photo-2062431.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span> 
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
                </Carousel>
      </div>
      <div className="col-md-2" style={{padding:'3px'}}>
      <Carousel responsive={responsive} infinite={true} swipeable={false} >
                
             
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>

                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/2062431/pexels-photo-2062431.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
                </Carousel>
      </div>
  
      <div className="col-md-2" style={{padding:'3px'}} >
            
      <Carousel responsive={responsive} infinite={true} swipeable={false} >
              
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/1743229/pexels-photo-1743229.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>

                  
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1" alt="" />

                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
             
                <div className="carousel_img">
                    <img src="https://images.pexels.com/photos/2062431/pexels-photo-2062431.jpeg?auto=compress&cs=tinysrgb&dpr=2&h=650&w=940" alt="" />
                    <div className="listStar">
                      <para>52623 Donnie Roads</para>
                      <Link to="/overview"><p>Handmade Wooden Mouse</p></Link>
                      <span>$223.00/Night - Free Cancellation</span>
                      <h6>⭐⭐⭐⭐⭐</h6>
                    </div>
                </div>
                </Carousel>
      </div>
  
    </div>
    </>
  )
}

export default ChoiceTopHotel