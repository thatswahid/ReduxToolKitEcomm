import React from "react";
import "../Component/SliderCss.css";
import Destinations from "./Destinations";
import TopHotel from "./TopHotel";
function ImageSlider() {
  return (
    <>
      <div
        id="carouselExampleIndicators"
        className="carousel slide"
        data-ride="carousel"
      >
        <ol className="carousel-indicators">
          <li
            data-target="#carouselExampleIndicators"
            data-slide-to={0}
            className="active"
          />
          <li data-target="#carouselExampleIndicators" data-slide-to={1} />
          <li data-target="#carouselExampleIndicators" data-slide-to={2} />
        </ol>
        <div className="carousel-inner">
          <div className="carousel-item active">
            <img
              className="d-block w-100"
              src="https://i0.wp.com/theluxurytravelexpert.com/wp-content/uploads/2019/07/header4.jpg?fit=1300%2C731&ssl=1"
              alt="First slide"
            />
          </div>
          <div className="carousel-item">
            <img
              className="d-block w-100"
              src="https://images.pexels.com/photos/258154/pexels-photo-258154.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1"
              alt="Second slide"
            />
          </div>
          <div className="carousel-item">
            <img
              className="d-block w-100"
              src="https://www.luxuryhotelawards.com/wp-content/uploads/sites/8/2020/01/81-Aragu-Restaurant-Cru-Lounge-Exterior-View-1.jpg"
              alt="Third slide"
            />
          </div>
        </div>
        <a
          className="carousel-control-prev"
          href="#carouselExampleIndicators"
          role="button"
          data-slide="prev"
        >
          {/* <span className="carousel-control-prev-icon" aria-hidden="true" /> */}
          <span className="sr-only">Previous</span>
        </a>
        <a
          className="carousel-control-next"
          href="#carouselExampleIndicators"
          role="button"
          data-slide="next"
        >
          {/* <span className="carousel-control-next-icon" aria-hidden="true" /> */}
          <span className="sr-only">Next</span>
        </a>
      </div>

      <div className="reviews">
        <div className="wrapper_reviews">
          <h3>Latest reviews. Lowest prices.</h3>
          <p>
            compares prices from 200+ booking sites to help you find the lowest
            price on the right hotel for you.
          </p>
          <div className="spanInput">
            

            <span>
              <input type="text" placeholder='Search"India" ' />
            </span>
            
         
            <span><input type="date" name="dob" data-placeholder="Start Date" required aria-required="true" /></span>
            <span>
             <input type="date" name="dob" data-placeholder="End Date" required aria-required="true" />
            </span>
            <span>
              <input type="text" placeholder="Room" />
            </span>
            <span>
             <input type="text" placeholder="Guest" />
            </span>
            <span>
              <button>Find Hotel</button>
            </span>
          </div>
        </div>
      </div>
      <Destinations/>
      <TopHotel/>
    </>
  );
}

export default ImageSlider;
