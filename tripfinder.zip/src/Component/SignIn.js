import React from 'react'
import { Link } from 'react-router-dom'
import './SignIn.css'

function SignIn() {
    return (
        <>
            <div className="signIn" >
                <div className="row " style={{margin:"0px"}}>
                    <div className="col-md-5">
                        <div className='container SignInForm_25522'>
                            <a href="" style={{textDecoration:"none"}}>
                            <div className='logo_26522'>
                                <span><img src="https://tripfinder-redq.firebaseapp.com/static/media/logo-alt.980da429.svg" alt="" style={{ width: "25px", height: "39px" }} /></span> <span><h3>TripFinder.</h3></span>
                                </div></a>
                            <h1>Welcome Back</h1>
                            <p>Please log into your account</p>
                            <div className="SignInForm ">
                                <div>
                                    <label htmlFor="">Email</label>
                                    <input type="text" className='form-control' placeholder='Enter Ypur Email' name="" id="" style={{ lineHeight: "35px" }} />
                                </div><br />

                                <div>
                                    <label htmlFor="">Password</label>
                                    <input type="text" className='form-control' placeholder='Enter Your Password' name="" id="" style={{ lineHeight: "35px" }} />
                                </div>
                                <div>
                                    <button className='btnBtn_25522'>Log In</button>
                                    <p style={{ textAlign: "center", marginTop: "30px" }}>Or log in with</p>
                                </div>

                                <div className=' '>
                                    <div className="row "  >
                                        <div className="col-md-6">
                                            <button className='btn1_25522 btnbtn_255221 form-control'>Facebook</button>
                                        </div>
                                        <div className="col-md-6">
                                            <button className='btn1_25522 btnbtn_255222 form-control'>GitHub</button>
                                        </div>
                                        <div className="col-md-6" >
                                            <button className='btn1_25522 btnbtn_255223 form-control'>FireBase</button>
                                        </div>
                                        <div className="col-md-6">
                                            <button className='btn1_25522 btnbtn_255224 form-control'>Google +</button>
                                        </div>

                                    </div>
                                    <p style={{ textAlign: "center" }} className="sc-fzoXWK leiFTm mt-4">Don't Have an Account?&nbsp;<Link to="/signup" style={{ color:"#008489", fontWeight:"700"}}>Registration</Link></p>
                                </div>
                            </div>
                        </div>
                    </div>


                    <div className="col-md-7">
                        <div>
                            <img src="https://tripfinder-redq.firebaseapp.com/static/media/login-page-bg.eea21cfc.jpg" alt="" style={{ width: "100%" }} />
                        </div>
                    </div>
                </div>
            </div>
        </>
    )
}

export default SignIn