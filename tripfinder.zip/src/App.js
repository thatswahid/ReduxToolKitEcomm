import './App.css';
import Routing from './Component/Routing';

function App() {
  return (
    <div >
        <Routing/>
    </div>
  );
}

export default App;
